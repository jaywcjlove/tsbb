Koa Example
---

Compile files.

```bash
npm run watch # Listen compile .ts files.
npm run build # compile .ts files.
```

Production mode starts the service.

```bash
npm run start
```

Automatically restarting the node application when file changes in the directory are detected.

```bash
npm run dev 
```