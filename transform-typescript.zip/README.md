Transform Typescript Example
---

Feature: Just delete the typescript type.