export function abs(a: number, b: number) {
  return a + b;
}
