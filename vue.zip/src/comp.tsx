// import { defineComponent, h } from 'vue';
// export const Com = defineComponent({
//   name: 'Com',
//   render() {
//     return <div>Com Test</div>;
//   },
// });

export const Com = () => <div>Com</div>;
