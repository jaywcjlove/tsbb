import { defineComponent, h } from 'vue';

export * from './comp';

export default defineComponent({
  name: 'Login',
  render() {
    return <div>test</div>;
  },
});
