import React from 'react';
// import Button from '../src';
import './App.less';

export default class App extends React.PureComponent {
  render() {
    return <div className="warpper">test</div>;
  }
}
