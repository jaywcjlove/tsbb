/**
 * 这里是注释
 * @param a
 * @param b
 */
export function abs(a: number, b: number, c?: string) {
  return a + b;
}

export type TestGood2333 = {
  aaaa: string;
  xxxx: number;
  wwww: number;
  good: number;
};
