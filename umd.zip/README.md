UMD Example
---

## Quick Start

```shell
$ npx create-kkt my-app -e umd
cd my-app
$ npm install

$ npm run watch # Listen compile .ts files.
$ npm run build # compile .ts files.

$ npm run start
```
